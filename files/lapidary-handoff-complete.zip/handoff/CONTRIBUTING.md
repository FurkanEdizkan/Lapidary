# Contributing to Lapidary

## Commits — Conventional Commits 1.0.0
`<type>(<scope>): <description>` — types: `feat`, `fix`, `docs`, `refactor`, `perf`,
`test`, `build`, `ci`, `chore`. Use `!` or a `BREAKING CHANGE:` footer for breaking
changes. Enforced by cocogitto (`cog.toml`): install hooks once with
`cargo install cocogitto && cog install-hook --all`.

## Branches — Conventional Branch
`<type>/<short-description>`, lowercase, hyphenated (e.g. `feat/blender-worker`).
Branch off `main`; land via PR. `main` is protected and always releasable.

## PRs
Squash-merge with the **PR title as the conventional commit** — keeps `main` history
clean and machine-parseable for changelog/version bumping.

## Quality gate (must pass — see `.github/workflows/ci.yml`)
- `cargo fmt --all --check`
- `cargo clippy --workspace --all-targets --all-features -- -D warnings`
- `cargo test --workspace`

Follow the `modular-services` skill: one responsibility, typed input → typed output,
one public entrypoint per unit.

## CLA
Outside contributions require signing the Contributor License Agreement so the project
can offer the commercial license (see ADR-0004). The CLA text ships in Phase 5.
