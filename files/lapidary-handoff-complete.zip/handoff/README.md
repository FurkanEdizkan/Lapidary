# Lapidary — full-Rust workspace (Phase 0 scaffold)

A fast, dark-themed local gallery for 3D-printable models (STL · 3MF · OBJ). This tree is
the **Phase 0** scaffold of the migration from the original Node/Fastify backend to a
fully-Rust core + server. It compiles, is clippy-clean, and records the D1–D5 decisions as
ADRs. No application behaviour is implemented yet — that is Phases 1–6.

## Layout
```
crates/
  lapidary-core    # domain types + API DTO contracts (+ Phase 1 in-process mesh)
  lapidary-db      # SQLite schema/migrations/repositories (Phase 1)
  lapidary-server  # axum HTTP API (Phase 2)
  lapidary-worker  # job queue + Blender/stl-thumb render pipeline (Phase 3)
  rust-mesh        # original dependency-free mesh CLI, preserved verbatim
docs/adr/          # decision records D1–D5
```

## Develop
```bash
cargo fmt --all --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace
cargo build --workspace
```

## Integrating into the existing repo
Copy `crates/`, `docs/adr/`, `Cargo.toml`, `rust-toolchain.toml`, `rustfmt.toml`,
`cog.toml`, and `.github/workflows/ci.yml` into the repo root. Keep the existing `web/`
(Track A, ADR-0001) and `server/` side-by-side until Phase 6 cutover, then delete `server/`.

See `docs/adr/` for decisions and the ultraplan for the full phase plan.
