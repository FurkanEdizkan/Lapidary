# 0005 — Render engine default

**Status:** Accepted
**Decision (D5):** Default headless thumbnail render is **Blender Cycles** at low samples;
**`stl-thumb`** is the fast path; **EEVEE** only behind `xvfb-run`/EGL.

**Why:** Cycles renders headless with no display or virtual framebuffer, CPU or GPU. EEVEE
needs an OpenGL context, which is the classic headless-server failure. The worker tries
embedded-thumbnail extraction first (pure Rust, free) and only renders as a fallback.

**GPU:** worker container claims the GPU via `nvidia-container-toolkit` (`gpus: all`) for
OPTIX/CUDA Cycles; Cycles-CPU is the fallback so the same compose file runs on a laptop.
