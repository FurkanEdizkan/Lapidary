# 0003 — Mesh in-process vs sidecar

**Status:** Accepted
**Decision (D3):** Promote the dependency-free `rust-mesh` crate into a **library**
(`lapidary-core::mesh`) called **in-process**. Keep a thin `rust-mesh` CLI `bin` for
debugging only. Retire the `MESH_SIDECAR_BIN` env var and the spawn-per-file path.

**Why:** No subprocess overhead per file, shared types with the server, and the parser
already exists and works (STL ascii+binary, OBJ, bbox, vertex-clustering LOD). Phase 1
extends it with 3MF parse, embedded-thumbnail extraction, and watertight/volume.

**Phase 0 state:** `rust-mesh` is preserved **verbatim** as a workspace member so no
working code is lost; `lapidary-core::mesh` holds the target `MeshStats` contract as a
stub. Phase 1 moves the logic and makes the CLI re-export the library.
