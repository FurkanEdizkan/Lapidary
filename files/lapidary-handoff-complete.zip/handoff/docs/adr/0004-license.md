# 0004 — License model

**Status:** Accepted (pending legal review)
**Decision (D4):** **AGPL-3.0-only** for the open-source distribution, plus a **commercial
exception** (`COMMERCIAL.md`) sold to organisations that cannot comply with AGPL's
network-copyleft. Workspace `Cargo.toml` metadata is set to `AGPL-3.0-only`.

**Why:** Real OSI open source (community trust) where AGPL's network clause pushes large
orgs running a modified service to either comply or buy a commercial license — the
"free for small, pay if big" lever, MySQL/GitLab style.

**Hard requirement:** A **CLA** is required *before* accepting outside contributions, or
the project loses the right to sell exceptions later. `CONTRIBUTING.md` references it.

**Alternative considered:** PolyForm Small Business (explicit company-size gate) — rejected
for now because it is source-available, not OSI open source, costing goodwill/contributions.

**Caveat:** Licensing has real legal consequences; confirm with a lawyer before Phase 5
ships `LICENSE` + `COMMERCIAL.md`.
