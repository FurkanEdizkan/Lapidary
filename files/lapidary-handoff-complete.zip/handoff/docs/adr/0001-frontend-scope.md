# 0001 — Frontend scope

**Status:** Accepted (default — REVISIT before Phase 4)
**Decision (D1):** Keep the existing **React/Vite** frontend and point it at the new
Rust API. The API contract is unchanged, so this is near-zero frontend work.

**Why:** "Fully Rust" is taken to mean **core + server**. The Three.js viewer needs JS
interop regardless of backend language, and the ~20 existing components work. Rewriting
the UI in Leptos/Dioxus is high effort for low parity-value.

**Note:** The owner expressed a strong "fully Rust / Rust community" preference. If that
extends to the UI, flip to **Track B (Leptos or Dioxus, WASM)** — added as an *optional*
Phase 4B *after* backend parity, never as a blocker. The backend scaffold is identical
either way, so this decision can change without reworking Phases 0–3.
