# Architecture Decision Records

Phase 0 of the full-Rust migration. Each ADR records one decision (D1–D5) from the
ultraplan. Status `Accepted` decisions drive the scaffold; revisit dates are noted.

- [0001 — Frontend scope](0001-frontend-scope.md) · *Accepted (default), revisit at Phase 4*
- [0002 — SQLite driver](0002-sqlite-driver.md)
- [0003 — Mesh in-process vs sidecar](0003-mesh-in-process.md)
- [0004 — License model](0004-license.md)
- [0005 — Render engine default](0005-render-engine.md)
