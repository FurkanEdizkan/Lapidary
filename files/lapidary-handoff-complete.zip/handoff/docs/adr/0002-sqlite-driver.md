# 0002 — SQLite driver

**Status:** Accepted
**Decision (D2):** Use **`sqlx`** (sqlite, tokio runtime, compile-time-checked queries,
built-in migrations).

**Why:** Async-native (fits axum), typed queries catch schema drift at compile time,
and migrations are first-class — which matters because migration `0001` must reproduce
the current schema verbatim.

**Fallback (pre-authorized):** If `sqlx` SQLite async quirks (WAL, busy timeout) cause
friction, switch to **`rusqlite` + `deadpool-sqlite`** on `tokio::task::spawn_blocking`,
which mirrors the current synchronous `better-sqlite3` model. No need to re-open the
decision — the fallback is already approved.
