//! # lapidary-core
//!
//! Domain types and the API DTO contracts for Lapidary. These structs are ported
//! 1:1 from the original `server/src/services/types.ts` and **must serialize to the
//! exact same camelCase JSON** the React frontend already consumes — that contract
//! is the migration spec. Phase 1 adds snapshot tests pinning this JSON against
//! captures from the live Node API.
//!
//! The `mesh` module is a Phase-1 placeholder that will absorb the `rust-mesh`
//! crate (STL/OBJ/3MF parse, bbox, LOD, watertight/volume, embedded-thumbnail
//! extraction) so mesh work runs in-process instead of via a spawned binary.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

/// A model as shown in the gallery grid. Mirrors `ModelDTO` from the TS server.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelDto {
    pub id: String,
    pub name: String,
    pub creator: String,
    /// `type` is a Rust keyword, so the field is renamed; JSON stays `"type"`.
    #[serde(rename = "type")]
    pub model_type: String,
    pub mesh_kind: Option<String>,
    pub color: String,
    pub format: String,
    pub file_size_bytes: i64,
    /// Bounding box in mm, serialized as the `size` triple `[x, y, z]`.
    pub size: [f64; 3],
    pub triangle_count: i64,
    pub created: Option<String>,
    pub added: String,
    pub tags: Vec<String>,
    pub groups: Vec<String>,
    pub printers: Vec<String>,
    pub has_thumbnail: bool,
    pub has_lod: bool,
    pub has_original: bool,
}

/// One editable print-setting row. Mirrors `SettingRow`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SettingRow {
    pub id: i64,
    pub k: String,
    pub v: String,
    pub source: String,
}

/// A printed/painted result photo (or other image). Mirrors `ImageDTO`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ImageDto {
    pub id: i64,
    pub url: String,
    pub caption: Option<String>,
    pub kind: String,
}

/// Full detail payload for a single model's page. Mirrors `ModelDetailDTO`,
/// which in TS `extends ModelDTO` — reproduced here with `#[serde(flatten)]`
/// so the base fields appear at the top level exactly as before.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelDetailDto {
    #[serde(flatten)]
    pub base: ModelDto,
    pub notes: Option<String>,
    pub settings: Vec<SettingRow>,
    pub images: Vec<ImageDto>,
}

/// Gallery filter/query parameters. Mirrors `ModelFilter`; every field optional.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelFilter {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub search: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tags: Option<Vec<String>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub group: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub creator: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sort: Option<String>,
}

/// In-process mesh routines. Phase 1 promotes the `rust-mesh` crate into here.
pub mod mesh {
    use serde::{Deserialize, Serialize};

    /// Geometry summary extracted from a mesh file. Phase 1 fills in the parser
    /// (currently lives, dependency-free, in the `rust-mesh` crate).
    #[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
    #[serde(rename_all = "camelCase")]
    pub struct MeshStats {
        /// Bounding-box extents in mm `[x, y, z]`.
        pub bbox: [f64; 3],
        pub triangle_count: u64,
        /// Filled by the Phase-1 watertight check.
        pub watertight: Option<bool>,
        /// Volume in mm^3 (Phase 1).
        pub volume: Option<f64>,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Locks the DTO key names early. Phase 1 replaces/extends this with golden
    /// snapshots captured from the live Node API for full contract parity.
    #[test]
    fn model_dto_serializes_camel_case_keys() {
        let dto = ModelDto {
            id: "m1".into(),
            name: "Dragon".into(),
            creator: "Unknown".into(),
            model_type: "Miniature".into(),
            mesh_kind: None,
            color: "#bcc0c8".into(),
            format: "STL".into(),
            file_size_bytes: 1024,
            size: [10.0, 20.0, 30.0],
            triangle_count: 42,
            created: None,
            added: "2026-01-01".into(),
            tags: vec!["dragon".into()],
            groups: vec![],
            printers: vec![],
            has_thumbnail: true,
            has_lod: true,
            has_original: true,
        };
        let v = serde_json::to_value(&dto).unwrap();
        assert!(
            v.get("type").is_some(),
            "model type must serialize as `type`"
        );
        assert!(v.get("fileSizeBytes").is_some());
        assert!(v.get("triangleCount").is_some());
        assert!(v.get("hasThumbnail").is_some());
        assert!(v.get("size").is_some());
    }
}
