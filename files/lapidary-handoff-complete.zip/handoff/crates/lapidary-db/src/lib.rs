//! # lapidary-db
//!
//! Persistence layer for Lapidary. **Phase 1** lands here:
//! - migration `0001` = the current SQLite schema *verbatim* (9 tables, WAL,
//!   `foreign_keys = ON`, `user_version` honoured) so an existing `lapidary.db`
//!   opens untouched;
//! - migration `0002` = the `jobs` table for the Phase 3 worker;
//! - typed repositories returning `lapidary-core` DTOs.
//!
//! Phase 0 is an empty, compiling skeleton.

#![forbid(unsafe_code)]

/// Schema version implemented so far. Bumped as migrations are added.
pub const SCHEMA_VERSION: u32 = 0;
