//! # lapidary-worker
//!
//! Background job runner. **Phase 3** implements: poll the `jobs` table, try
//! embedded-thumbnail extraction first (pure Rust), else render via `stl-thumb`
//! or headless Blender (Cycles), then write thumbnail + Draco-GLB back. Runs in
//! its own (heavy) container next to the lean server. Phase 0 is a placeholder.

fn main() {
    println!(
        "lapidary-worker {} — Phase 0 scaffold (render pipeline arrives in Phase 3)",
        env!("CARGO_PKG_VERSION")
    );
}
