//! # lapidary-server
//!
//! The axum HTTP API. **Phase 2** ports the 18 services and reproduces the exact
//! `/api` surface (models, tags, groups, pins, printer-types, printer-settings,
//! images, search/suggest, scan, profile-import, asset serving) plus `ServeDir`
//! for the built SPA. Phase 0 is a placeholder entrypoint.

fn main() {
    println!(
        "lapidary-server {} — Phase 0 scaffold (axum API arrives in Phase 2)",
        env!("CARGO_PKG_VERSION")
    );
}
